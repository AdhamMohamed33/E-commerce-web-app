package StepDefinitions;

import PomPages.P07_ProductColorStepDef;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;

public class D07_ProductColor {
P07_ProductColorStepDef select=new P07_ProductColorStepDef();
    @Given("user should select specific category like Apparel")
    public void apparelClick()
    {
      select.ApparelLocator().click();
    }
   @When("user should select shoes")
    public void ShoesClick()
   {
     select.ShoesLocator().click();
   }

@And("user choose any color")
public void ChooseColor()
{
  select.ColorLocator().click();
}
@Then("user found his product color")
    public void ProductColor()
{
   boolean item= select.ShoesItem().isDisplayed();
   Assert.assertTrue(item);
   String expected="https://demo.nopcommerce.com/shoes?viewmode=grid&orderby=0&pagesize=6&specs=15";
  String actual= Hooks.driver.getCurrentUrl();
    Assert.assertTrue(actual.contains(expected));

}

}
