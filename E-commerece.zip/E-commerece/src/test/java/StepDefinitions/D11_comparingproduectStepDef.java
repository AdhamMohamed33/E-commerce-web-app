package StepDefinitions;

import PomPages.P11_ComaringProdPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class D11_comparingproduectStepDef {

    P11_ComaringProdPom compare=new P11_ComaringProdPom();
@Given("first product to compare")
public void firstProduct() {
    compare.comparsion1Button().get(2).click();

}
    @And("user click on computers category")
    public void  user_click_on_computers_category ()
    {
       compare.computersCat().click();

    }
    @And("user choose Desktops category")
    public void user_choose_Desktops_category ()
    {
       compare.Desktopscat().click();
    }
    @When("user choose a second product to add it in comparison list")
    public void user_choose_a_product_to_add_it_in_comparison_list () throws InterruptedException {
        compare.FirstProduct().get(0).click();
        Thread.sleep(1000);

    }

    @And("user click on copmarison list")
    public void user_click_on_copmarison_list()
    {
     compare.comparisonlistclick().click();

    }
    @Then("user added products successfully and compare between products")
    public void  user_added_products_successfully_and_compare_between_products ()
    {
      String actual=Hooks.driver.getCurrentUrl();
      String expected="https://demo.nopcommerce.com/compareproducts";
      Assert.assertTrue(actual.contains(expected));


    }

}
