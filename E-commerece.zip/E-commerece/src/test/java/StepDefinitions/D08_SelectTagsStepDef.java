package StepDefinitions;

import PomPages.P08_SelectTag;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class D08_SelectTagsStepDef {
    P08_SelectTag selecttag=new P08_SelectTag();
    @Given("user should select any category")
    public void selecCateg()
    {
       selecttag.ApparelLoc().click();
    }
    @When("user should select any tag like book")
    public void selecTag()
    {
      selecttag.bookTag().click();
    }
    @Then("website got to product tag name book")
    public void ProductTagName() throws InterruptedException {
      Thread.sleep(1000);
        String actual= Hooks.driver.getCurrentUrl();
      String excpected="https://demo.nopcommerce.com/book";
        Assert.assertTrue(actual.contains(excpected));
    }
    @Given("user select a different category")
    public void diffCategory()
    {
         selecttag.jewerly().click();

    }

    @When("user select a tag like computer")
    public void selecCompuTag()
    {
         selecttag.computerTag().click();

    }

    @Then("website got to product tag name computer")
    public void ProducttTagName() throws InterruptedException {
       Thread.sleep(1000);
        String actual=Hooks.driver.getCurrentUrl();

                String excpected="https://demo.nopcommerce.com/computer";

                Assert.assertTrue(actual.contains(excpected));

    }
}
