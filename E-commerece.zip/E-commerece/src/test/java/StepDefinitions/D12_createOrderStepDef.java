package StepDefinitions;

import PomPages.P02_loginPom;
import PomPages.P12_CreateOrderPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;

public class D12_createOrderStepDef {
P12_CreateOrderPom create= new P12_CreateOrderPom();
    @Given("user select a product and click on shoppingcart")
    public void Select_ProductShop()
    {
       create.TheProduct().get(2).click();
       create.shoppingcartclick().click();


    }


    @And("user agree with terms and checkout")
    public void AgreeTermsAndCheckout()
    {
       create.TermsClickOn().click();
       create.CheckOutButton().click();
    }



    @And("user select country")
    public void SelectCountry()
    {
      create.Country().click();

    }


    @And("^user fill all field of billing adress \"(.*)\" \"(.*)\" \"(.*)\" \"(.*)\" \"(.*)\" \"(.*)\"$")
    public void FillBillingAdress(String a,String b,String c,String d,String f,String g)
    {
        create.City().sendKeys(a);
        create.Adress1().sendKeys(b);
        create.Adress2().sendKeys(c);
        create.PostalCode().sendKeys(d);
        create.Phonenumber().sendKeys(f);
        create.FaxNumber().sendKeys(g);
    }


    @When("user continue purchase and confirm shipping method")
    public void confirmpurchase() throws InterruptedException {
        create.ContinueButtonFill().click();
        Thread.sleep(1000);

        create.ShippingContinue().click();

    }



    @And("user confirm payment method")
    public void PaymentConfirm()
    {
        create.PaymentMethodContinue().click();
    }



    @And("user confrim payment information")
    public void infPayConirm()
    {
         create.InfPayContinue().click();

    }



    @And("user confirm order")
    public void Confirmorder()
    {
      create.ConfirmOrderContinue().click();

    }




    @Then("user received confirmation message and successful order")
    public void checkmsgAndContunie() throws InterruptedException {
        Thread.sleep(1000);
        String actual=create.MsgConfirmation().getText();
        String expected="Your order has been successfully processed!";
        Assert.assertTrue(actual.contains(expected));
        create.FinishContinue().click();



    }



}
