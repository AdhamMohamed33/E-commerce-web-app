package StepDefinitions;


import PomPages.P06_CategoryPom;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class D06_CategoryStepDef {
P06_CategoryPom click=new P06_CategoryPom();
Actions action =new Actions(Hooks.driver);
    @Given("user hover the mouse on category that has sub_category")
    public void Category() throws InterruptedException {
        action.moveToElement(click.ComputersCategory()).perform();
        Thread.sleep(1000);
    }
  @When("user select on any category")
    public void Nb()
  {
      click.NoteBookSubCategory().click();
  }

  @Then("user could select sub_category successfully")
    public void sub_categ() throws InterruptedException { Thread.sleep(2000);
     String actual= Hooks.driver.getCurrentUrl();
     String expected="https://demo.nopcommerce.com/notebooks";
      Assert.assertTrue(actual.contains(expected));

  }
@Given("user hover on category has not sub_category")
    public void HoverCategoryNoSub()
{
    click.jewerly().click();

}


@When("user could select category successfully")
    public void successCategory()
{
    String actual= Hooks.driver.getCurrentUrl();
    String expected="https://demo.nopcommerce.com/jewelry";
    Assert.assertTrue(actual.contains(expected));

}


}
