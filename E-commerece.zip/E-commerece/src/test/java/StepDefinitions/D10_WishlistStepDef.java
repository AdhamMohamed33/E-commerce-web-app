package StepDefinitions;

import PomPages.P10_WishlistPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import java.lang.annotation.Target;

public class D10_WishlistStepDef {
    P10_WishlistPom wishlist = new P10_WishlistPom();

    @When("user add product to Wishlist")
    public void user_add_product_to_Wishlist() throws InterruptedException {
        wishlist.wishlistButton().get(2).click();
        Thread.sleep(1000);

    }

    @Then("wishlist notification success is visible")
    public void WishlistNotificationVisible() {
        wishlist.WishListMsg().isDisplayed();
        Assert.assertTrue(wishlist.WishListMsg().isDisplayed());


    }

    @Given("user click on wishlist button of another product")
    public void user_click_on_wishlist_button_of_another_product()
    {
      wishlist.wishlistButton2().get(0).click();


    }

  @And("user fill all mandatory data of product")
    public void user_fill_all_mandatory_data_of_product()
      {
          wishlist.mandatory1().click();
          wishlist.mandatory2().click();
          wishlist.mandatory3().click();
          wishlist.mandatory4().click();


      }
  @When("user add the product to Wishlist")
  public void user_add_the_product_to_Wishlist()
     {

         wishlist.AddCardButton().click();
      }

   @Then("Wishlist notification succsess is visible again")
    public void Wishlist_notification_succsess_is_visible_again()
   {
     wishlist.wishlistMsg2().isDisplayed();
     Assert.assertTrue(wishlist.wishlistMsg2().isDisplayed());


   }



}
