package StepDefinitions;

import PomPages.P01_SignUpPom;
import PomPages.P02_loginPom;
import PomPages.P04_searchProductPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class D04_SearchStepDef {
    P02_loginPom logged = new P02_loginPom();
    P04_searchProductPom search = new P04_searchProductPom();
    P01_SignUpPom signn = new P01_SignUpPom();




    @Given("^user write product name in searchbar: \"(.*)\"$")
    public void searchBar(String productName) {
        search.SearchBar().click();
        search.SearchBar().sendKeys(productName);
    }

    @When("user click on search button")
    public void searchButtonClick() {
        search.Search_Button().click();
    }

    @Then("user found the product successfully")
    public void foundProduct() {
        Hooks.driver.getCurrentUrl();
        String expectedUrl = "https://demo.nopcommerce.com/search?q=Desktops";
        Assert.assertEquals("https://demo.nopcommerce.com/search?q=Desktops", Hooks.driver.getCurrentUrl());


    }
}
