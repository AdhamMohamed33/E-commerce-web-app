package StepDefinitions;

import PomPages.P02_loginPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class D02_LoginStepDef {
    P02_loginPom login=new P02_loginPom();
 @Given("user go to login page")
    public void loginPage(){
    login.loginLink().click();
 }
@When("^user login with valid email \"(.*)\"$")
 public void validEmail(String email){
   login.emailField().sendKeys(email);

}
@And("^user login with valid password \"(.*)\"$")
public void validPass(String password)
{
    login.passwordlField().sendKeys(password);
}
@And("user press on login button")
    public void logincliick()
{
login.loginButton().click();
}
@Then("user login to the system successfully")
    public void loginSuccessfully() throws InterruptedException {
 login.myAccount().isDisplayed();
    Assert.assertTrue(login.myAccount().isDisplayed());
    Hooks.driver.getCurrentUrl();
    Assert.assertEquals("https://demo.nopcommerce.com/",Hooks.driver.getCurrentUrl());
}

    @When("^user login with invalid email \"(.*)\"$")
    public void invalidEmail(String email){
        login.emailField().sendKeys(email);

    }
    @And("^user login with invalid password \"(.*)\"$")
    public void invalidPass(String password)
    {
        login.passwordlField().sendKeys(password);
    }


@Then("user could not login to the system")
    public void loginUnsuccessfully() throws InterruptedException {
 Thread.sleep(1000);
String actual=login.ErrorMsg().getText();
String expected="Login was unsuccessful. Please correct the errors and try again";
Assert.assertTrue(actual.contains(expected));

String errormsg =login.ErrorMsg().getCssValue("color");
    System.out.println("the color of messageis:"+ errormsg);

}



}
