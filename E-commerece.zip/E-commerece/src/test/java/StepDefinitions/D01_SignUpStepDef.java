package StepDefinitions;

import PomPages.P01_SignUpPom;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class D01_SignUpStepDef {
P01_SignUpPom signUpPom=new P01_SignUpPom();



  @Given("user click on register link")
    public void userRL() {
    signUpPom.registerLink().click();

  }
    @When("user select the gender type")
    public void SelectGenderType()  {
        signUpPom.genderType().click();

    }

    @And("^user enter first name \"(.*)\" and last name \"(.*)\"$")
    public void firstnameAndLastname(String firstname,String lastname)
  {
      signUpPom.firstName().sendKeys(firstname);
      signUpPom.lastName().sendKeys(lastname);
  }


  @And("set date of birthday")
    public void DateOfBirthday()
  {
      signUpPom.DateOfBirthDay().click();
      signUpPom.DateOfBirthMonth().click();
      signUpPom.DateOfBirthYear().click();
  }

@And("^user enter the Email \"(.*)\"$")
    public void validEmail(String email)
{
    signUpPom.Email().sendKeys(email);
}

 @And("^user enter the company name \"(.*)\"$")
    public void CompanyName(String c)
 {
     signUpPom.companyName().sendKeys(c);
 }
 @And("user set the password \"(.*)\" and the confirm password \"(.*)\"$")
    public void PassValid(String password,String confirmpassword)
 {
     signUpPom.password().sendKeys(password);
     signUpPom.confirmPassword().sendKeys(confirmpassword);


 }

 @And("user click on register button")
    public void registeration()
 {
     signUpPom.registerButton().click();
 }
  @Then("user could register successfully")
    public void resultMsg() throws InterruptedException {
      Thread.sleep(2000);
      String expectedresult="Your registration completed";
      String actualresult= signUpPom.result().getText();
      Assert.assertTrue(actualresult.contains(expectedresult));
      Assert.assertEquals(Hooks.driver.getCurrentUrl(),"https://demo.nopcommerce.com/registerresult/1?returnUrl=/");

  }
  @And("user click on continue button")
    public void registrationSuccsessfully()
  {
      signUpPom.continueButton().click();

  }
}
