package StepDefinitions;

import PomPages.P03_recoverpassPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;

public class D03_recoverypassStepDef {
    P03_recoverpassPom forgetpass=new P03_recoverpassPom();

    @Given("click on login")
    public void user_go_to_loginPage()
    {
        forgetpass.loginrecover().click();
    }
    @And("user click on forget password")
    public void user_clickon_forget()
    {
        forgetpass.forgetPass().click();
    }
    @When("^user enter his/her email \"(.*)\"$")
    public void hisEmail(String email)
    {
        forgetpass.yourEmailAdress().sendKeys(email);
        forgetpass.yourEmailAdress().sendKeys(Keys.ENTER);
    }
    @Then("the password recovers successfully")
    public void successesRecovery() throws InterruptedException {
        Thread.sleep(3000);
        forgetpass.recoveryMsg().isDisplayed();

        Hooks.driver.getCurrentUrl();
        Assert.assertEquals("https://demo.nopcommerce.com/passwordrecovery",Hooks.driver.getCurrentUrl());
        String expectedMsg="Email with instructions has been sent to you.";
        String actualMsg= forgetpass.recoveryMsg().getText();
        Assert.assertTrue(actualMsg.contains(expectedMsg));



    }
}
