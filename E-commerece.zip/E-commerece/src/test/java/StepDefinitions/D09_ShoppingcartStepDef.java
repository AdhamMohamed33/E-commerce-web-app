package StepDefinitions;

import PomPages.P09_shoppingPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class D09_ShoppingcartStepDef {
    P09_shoppingPom shop =new P09_shoppingPom();
    @When("user add product to shoppingcart")
    public void user_add_product_to_shoppingcart() throws InterruptedException {
        shop.AddcartButton1().get(2).click();
        Thread.sleep(1000);

    }

    @Then("shoppingcart notification success is visible")
    public void shoppingcartNotificationVisible() {
        shop.shoppingcartMsg().isDisplayed();
        Assert.assertTrue(shop.shoppingcartMsg().isDisplayed());

    }
    @Given("user click on addcart button of another product")
    public void user_click_on_addcart_button_of_another_product()
    {
     shop.addcartButton2().get(0).click();

    }

    @And("user fill data of product")
    public void user_fill_data_of_product()
    {
        shop.data1().click();
        shop.data2().click();
        shop.data3().click();
        shop.data4().click();


    }
    @When("user add the product to shoppingcart")
    public void user_add_the_product_to_shoppingcart()
    {

     shop.AddCardclick().click();
    }

    @Then("shoppingcart notification succsess is visible again")
    public void shoppingcart_notification_succsess_is_visible_again()
    {
        shop.shoppingcartMsg2().isDisplayed();
        Assert.assertTrue(shop.shoppingcartMsg2().isDisplayed());


    }

}
