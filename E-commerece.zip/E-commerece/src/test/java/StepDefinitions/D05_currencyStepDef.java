package StepDefinitions;

import PomPages.P02_loginPom;
import PomPages.P05_CurrencyPom;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class D05_currencyStepDef {
    P02_loginPom log =new P02_loginPom();
    P05_CurrencyPom customer=new P05_CurrencyPom();
    @And("^user logged \"(.*)\" \"(.*)\"$")
    public void user_logged(String email,String password) throws InterruptedException {
        log.loginLink().click();
        log.emailField().sendKeys(email);
        log.passwordlField().sendKeys(password);
        log.loginButton().click();
        Thread.sleep(2000);
    }

    @Given("click on us-euro checklist")
    public void checklist()
    {
     customer.checklistt().click();
    }
    @When("click on euro")
    public void Euro()
    {
      customer.Euro_button().click();
    }
    @Then("change between usdolar and euro happend")
    public void change()
    {
        Hooks.driver.getCurrentUrl();
        String expectedUrl="https://demo.nopcommerce.com/";
        Assert.assertEquals(expectedUrl,Hooks.driver.getCurrentUrl());

    }

}
