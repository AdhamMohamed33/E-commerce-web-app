package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P01_SignUpPom {


    public WebElement registerLink()
    {
        return Hooks.driver.findElement(By.cssSelector("a[class=\"ico-register\"]"));
    }

    public WebElement genderType()
    {
        return Hooks.driver.findElement(By.id("gender-male"));
    }

    public WebElement firstName()
    {
        return Hooks.driver.findElement(By.id("FirstName"));
    }

    public WebElement lastName()
    {
        return Hooks.driver.findElement(By.id("LastName"));
    }

    public WebElement DateOfBirthDay()
    {
        return Hooks.driver.findElement(By.cssSelector("select[name=\"DateOfBirthDay\"]>option[value=\"2\"]"));
    }

    public WebElement DateOfBirthMonth()
    {
        return Hooks.driver.findElement(By.cssSelector("select[name=\"DateOfBirthMonth\"]>option[value=\"2\"]"));
    }

    public WebElement DateOfBirthYear()
    {
        return Hooks.driver.findElement(By.cssSelector("select[name=\"DateOfBirthYear\"]>option[value=\"1997\"]"));
    }

    public WebElement Email()
    {
        return Hooks.driver.findElement(By.id("Email"));
    }

    public WebElement companyName()
    {
        return Hooks.driver.findElement(By.id("Company"));
    }

    public WebElement password()
    {
        return Hooks.driver.findElement(By.id("Password"));
    }

    public WebElement confirmPassword()
    {
        return Hooks.driver.findElement(By.id("ConfirmPassword"));
    }

    public WebElement registerButton()
    {
        return Hooks.driver.findElement(By.id("register-button"));
    }

    public WebElement result()
    {
        return Hooks.driver.findElement(By.cssSelector("div[class=\"result\"]"));
    }
    public WebElement continueButton()
    {
        return Hooks.driver.findElement(By.cssSelector("a[class=\"button-1 register-continue-button\"]"));

    }



}
