package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P07_ProductColorStepDef {

    public WebElement ApparelLocator()
    {
        return Hooks.driver.findElement(By.cssSelector("a[href=\"/apparel\"]"));
    }

    public WebElement ShoesLocator()
    {
        return Hooks.driver.findElement(By.cssSelector("a[title=\"Show products in category Shoes\"]"));
    }

    public WebElement ColorLocator()
    {
        return Hooks.driver.findElement(By.id("attribute-option-15"));
    }

    public WebElement ShoesItem()
    {
        return Hooks.driver.findElement(By.cssSelector("a[href=\"/adidas-consortium-campus-80s-running-shoes\"]"));
    }
}
