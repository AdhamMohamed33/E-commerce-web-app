package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P04_searchProductPom {

    public WebElement SearchBar() {
        return Hooks.driver.findElement(By.id("small-searchterms"));
    }

    public WebElement Search_Button() {
        return Hooks.driver.findElement(By.cssSelector("button[class=\"button-1 search-box-button\"]"));
    }



}
