package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P02_loginPom {
    public WebElement loginLink() {
        return Hooks.driver.findElement(By.cssSelector("a[class=\"ico-login\"]"));
    }

    public WebElement emailField() {
        return Hooks.driver.findElement(By.id("Email"));
    }

    public WebElement passwordlField() {
        return Hooks.driver.findElement(By.id("Password"));
    }

    public WebElement loginButton() {

        return Hooks.driver.findElement(By.cssSelector("button[class=\"button-1 login-button\"]"));
    }

    public WebElement myAccount() {
        return Hooks.driver.findElement(By.cssSelector("a[class=\"ico-account\"]"));
    }

    public WebElement ErrorMsg() {
        return Hooks.driver.findElement(By.cssSelector("div[class=\"message-error validation-summary-errors\"]"));
    }
}