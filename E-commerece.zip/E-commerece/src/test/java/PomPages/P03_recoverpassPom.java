package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P03_recoverpassPom {

    public WebElement loginrecover() {
        return Hooks.driver.findElement(By.cssSelector("a[class=\"ico-login\"]"));
    }

    public WebElement forgetPass() {
        return Hooks.driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[2]/div[3]/span/a"));
    }
    public WebElement yourEmailAdress() {
        return Hooks.driver.findElement(By.id("Email"));
    }
    public WebElement recoveryMsg()
    {
       return Hooks.driver.findElement(By.cssSelector("p[class=\"content\"]"));
    }

}
