package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class P11_ComaringProdPom {

    public List<WebElement> comparsion1Button(){

        return Hooks.driver.findElements(By.cssSelector("button[class=\"button-2 add-to-compare-list-button\"]"));

    }
    public WebElement computersCat ()
    {

        return Hooks.driver.findElement(By.cssSelector("a[href=\"/computers\"]"));
    }
    public WebElement Desktopscat ()
    {

        return Hooks.driver.findElement(By.cssSelector("a[title=\"Show products in category Desktops\"]"));
    }
    public List<WebElement> FirstProduct ()
    {

        return Hooks.driver.findElements(By.xpath("/html/body/div[6]/div[3]/div/div[3]/div/div[2]/div[2]/div[2]/div/div/div[1]/div/div[2]/div[3]/div[2]/button[2]"));
    }

    public WebElement comparisonlistclick ()
    {

        return Hooks.driver.findElement(By.xpath("//*[@id=\"bar-notification\"]/div/p/a"));
    }
    public WebElement ComarisonListMsg ()
    {

        return Hooks.driver.findElement(By.cssSelector("p[class=\"content\"]"));
    }






}
