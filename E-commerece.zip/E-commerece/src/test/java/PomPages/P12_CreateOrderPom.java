package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class P12_CreateOrderPom {
    public List<WebElement> TheProduct(){

        return Hooks.driver.findElements(By.cssSelector("button[class=\"button-2 product-box-add-to-cart-button\"]"));

    }
    public WebElement shoppingcartclick()
    {

        return Hooks.driver.findElement(By.xpath("//*[@id=\"bar-notification\"]/div/p/a"));
    }
    public WebElement TermsClickOn()
    {

        return Hooks.driver.findElement(By.id("termsofservice"));
    }

    public WebElement CheckOutButton()
    {
        return Hooks.driver.findElement(By.id("checkout"));
    }
    public WebElement Country()
    {
        return Hooks.driver.findElement(By.xpath("//*[@id=\"BillingNewAddress_CountryId\"]/option[5]"));
    }
    public WebElement City()
        {
          return Hooks.driver.findElement(By.id("BillingNewAddress_City"));
        }
    public WebElement Adress1()
    {
        return Hooks.driver.findElement(By.id("BillingNewAddress_Address1"));
    }
    public WebElement Adress2()
    {
        return Hooks.driver.findElement(By.id("BillingNewAddress_Address2"));
    }
    public WebElement PostalCode()
    {
        return Hooks.driver.findElement(By.id("BillingNewAddress_ZipPostalCode"));
    }
    public WebElement Phonenumber()
    {
        return Hooks.driver.findElement(By.id("BillingNewAddress_PhoneNumber"));
    }
    public WebElement FaxNumber()
    {
        return Hooks.driver.findElement(By.id("BillingNewAddress_FaxNumber"));
    }
    public WebElement ContinueButtonFill()
    {
        return Hooks.driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/button[4]"));
    }

    public WebElement ShippingContinue()
    {
        return Hooks.driver.findElement(By.cssSelector("class=\"button-1 shipping-method-next-step-button\""));
    }
    public WebElement PaymentMethodContinue()
    {
        return Hooks.driver.findElement(By.cssSelector("button[class=\"button-1 payment-method-next-step-button\"]"));
    }

    public WebElement InfPayContinue()
    {
        return Hooks.driver.findElement(By.cssSelector("button[class=\"button-1 payment-info-next-step-button\"]"));
    }

    public WebElement ConfirmOrderContinue()
    {
        return Hooks.driver.findElement(By.cssSelector("button[class=\"button-1 confirm-order-next-step-button\"]"));
    }
    public WebElement MsgConfirmation()
    {
        return Hooks.driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div/div[1]/strong"));

    }
   public WebElement FinishContinue()
   {
       return Hooks.driver.findElement(By.cssSelector("button[class=\"button-1 order-completed-continue-button\"]"));

   }
}

