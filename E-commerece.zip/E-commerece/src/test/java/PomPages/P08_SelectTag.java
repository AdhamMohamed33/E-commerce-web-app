package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P08_SelectTag {
    public WebElement ApparelLoc()
    {
        return Hooks.driver.findElement(By.cssSelector("a[href=\"/apparel\"]"));
    }

    public WebElement bookTag()
    {
        return Hooks.driver.findElement(By.cssSelector("a[href=\"/book\""));

    }

    public WebElement jewerly()
    {

        return Hooks.driver.findElement(By.cssSelector("a[href=\"/jewelry\"]"));
    }


    public WebElement computerTag()
    {

        return Hooks.driver.findElement(By.cssSelector("a[style=\"font-size:120%\""));
    }


}
