package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import javax.xml.bind.annotation.W3CDomHandler;
import java.util.List;

public class P10_WishlistPom {

    public List<WebElement> wishlistButton(){

        return Hooks.driver.findElements(By.cssSelector("button[class=\"button-2 add-to-wishlist-button\"]"));

    }
   public WebElement WishListMsg()
   {

       return Hooks.driver.findElement(By.cssSelector("div[class=\"bar-notification success\"]"));
   }

    public List<WebElement> wishlistButton2(){

        return Hooks.driver.findElements(By.cssSelector("button[class=\"button-2 add-to-wishlist-button\"]"));

    }

    public WebElement mandatory1()
    {

        return Hooks.driver.findElement(By.cssSelector("option[data-attr-value=\"3\"]"));
    }

    public WebElement mandatory2()
    {

        return Hooks.driver.findElement(By.id("product_attribute_3_6"));
    }

    public WebElement mandatory3()
    {

        return Hooks.driver.findElement(By.id("product_attribute_4_8"));
    }

    public WebElement mandatory4()
    {

        return Hooks.driver.findElement(By.id("product_attribute_5_10"));
    }


    public WebElement AddCardButton()
    {

        return Hooks.driver.findElement(By.id("add-to-wishlist-button-1"));
    }

    public WebElement wishlistMsg2()
    {
        return Hooks.driver.findElement(By.cssSelector("p[class=\"content\"]"));
    }

}
