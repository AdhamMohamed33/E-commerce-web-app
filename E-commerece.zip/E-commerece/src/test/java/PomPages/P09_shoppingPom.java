package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class P09_shoppingPom {


    public List<WebElement> AddcartButton1(){

        return Hooks.driver.findElements(By.cssSelector("button[class=\"button-2 product-box-add-to-cart-button\"]"));

    }

    public WebElement shoppingcartMsg()
    {

        return Hooks.driver.findElement(By.cssSelector("p[class=\"content\"]"));
    }

    public List<WebElement> addcartButton2(){

        return Hooks.driver.findElements(By.cssSelector("button[class=\"button-2 product-box-add-to-cart-button\"]"));

    }
    public WebElement data1()
    {

        return Hooks.driver.findElement(By.cssSelector("option[data-attr-value=\"3\"]"));
    }

    public WebElement data2()
    {

        return Hooks.driver.findElement(By.id("product_attribute_3_6"));
    }

    public WebElement data3()
    {

        return Hooks.driver.findElement(By.id("product_attribute_4_8"));
    }

    public WebElement data4()
    {

        return Hooks.driver.findElement(By.id("product_attribute_5_10"));
    }

    public WebElement AddCardclick()
    {

        return Hooks.driver.findElement(By.id("add-to-cart-button-1"));
    }

    public WebElement shoppingcartMsg2()

    {
        return Hooks.driver.findElement(By.cssSelector("p[class=\"content\"]"));
    }


}
