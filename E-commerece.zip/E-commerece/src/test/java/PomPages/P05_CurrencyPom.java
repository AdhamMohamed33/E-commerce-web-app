package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P05_CurrencyPom {

    public WebElement checklistt()
    {
        return Hooks.driver.findElement(By.id("customerCurrency"));

    }
    public WebElement Euro_button()
    {
        return Hooks.driver.findElement(By.xpath("//*[@id=\"customerCurrency\"]/option[2]"));
    }


}
