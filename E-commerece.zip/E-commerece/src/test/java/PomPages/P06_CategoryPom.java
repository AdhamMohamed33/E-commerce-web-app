package PomPages;

import StepDefinitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P06_CategoryPom {

    public WebElement ComputersCategory ()
    {
        return Hooks.driver.findElement(By.cssSelector("a[href=\"/computers\"]"));

    }
    public WebElement jewerly()
    {

        return Hooks.driver.findElement(By.cssSelector("a[href=\"/jewelry\"]"));
    }
public WebElement NoteBookSubCategory()
{
    return Hooks.driver.findElement(By.cssSelector("a[href=\"/notebooks\"]"));
}




}
